#include <kipr/wombat.h>
//code the robot to drive out of the start box
//arm is in down position at start
//take a right turn
//drive to the lightswitch
//raise the arm to flip the switch
int main()
{
    //wait_for_light(0);
    shut_down_in(60);
    enable_servos();

    printf("Flip the switch!\n");
    set_servo_position(0,550);
    msleep(50);

    while(analog (5) < 2300)
    {
        motor(0,68);
        motor(3,80);
    }

    ao();
    msleep(500);

    motor(0,100);
    motor(3,100);
    msleep(500);

    motor(0,-80);
    motor(3,80);
    msleep(1000);

    while(digital(0)==0)//drive along black tape until it touches the coupler.
    {
        if (analog(5) <=1225)
        {
            motor(0,80);
            motor(3,-10);
        }
        else if(analog(5)> 1225)
        {
            motor(3,80);
            motor(0,-10);
        }

        motor(0,80);
        motor(3,80);

    }
    ao();
    motor(0,-80);
    motor(3,-80);
    msleep(800);

    motor(0,-50);
    motor(3,45);
    msleep(750);

    ao();
    msleep(500);
    set_servo_position(0,115);
    set_servo_position(2,180);
    msleep(50);

    motor(0,50);
    motor(3,50);
    msleep(1500);

    set_servo_position(2,1436);//grab the cube
    msleep(550);

    ao();
    msleep(50);

    set_servo_position(0,324);
    msleep(500);

    motor(0,-100);//drive backward
    motor(3,-100);
    msleep(2000);

    motor(3,100);//turn right
    motor(0,-100);
    msleep(1000);

    motor(0,87);//drive straight
    motor(3,90);
    msleep(6000);
    
    set_servo_position(0,115);
    msleep(50);
    printf("Look for the black line!\n");
    while(analog (5) < 2300)
    {
        motor(0,58);
        motor(3,70);
    }

    ao();
    msleep(500);
    


      while(digital(0)==0)//drive along black tape until it touches the coupler.
    {
        if (analog(5) <=1225)
        {
            motor(0,80);
            motor(3,-10);
        }
        else if(analog(5)> 1225)
        {
            motor(3,80);
            motor(0,-10);
        }

        motor(0,80);
        motor(3,80);

    }
    
    ao();







    return 0;
}
